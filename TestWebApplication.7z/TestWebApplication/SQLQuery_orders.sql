create table Orders(
ID_order int primary key identity(1,1),
Sender_city nvarchar(100),
Sender_address nvarchar(200),
Recipient_city nvarchar(100),
Address_of_the_recipient nvarchar(200),
Cargo_weight float,
Date_of_cargo_collection nvarchar(30))
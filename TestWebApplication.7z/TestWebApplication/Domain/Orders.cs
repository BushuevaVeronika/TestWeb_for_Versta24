﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace TestWebApplication.Models
{
    public class Orders
    {
        [Key]
        public int ID_order { get; set; }
        [Required(ErrorMessage = "Город отправителя обязателен")]
        public string Sender_city { get; set; }

        [Required(ErrorMessage = "Адрес отправителя обязателен")]
        public string Sender_address { get; set; }

        [Required(ErrorMessage = "Город получателя обязателен")]
        public string Recipient_city { get; set; }

        [Required(ErrorMessage = "Адрес получателя обязателен")]
        public string Address_of_the_recipient { get; set; }

        [Range(0, float.MaxValue, ErrorMessage = "Вес груза должен быть неотрицательным числом")]
        public double Cargo_weight { get; set; }
        public string Date_of_cargo_collection { get; set; }
    }
}

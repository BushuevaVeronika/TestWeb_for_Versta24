﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using TestWebApplication.Models;
namespace Дизайн_интерьера.Domain
{
    public class DBcontext : DbContext
    {
        public DbSet<Orders> Orders { get; set; }
        public DBcontext(DbContextOptions<DBcontext> options)
            : base(options)
        {
            Database.EnsureCreated();
        }
        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);
            builder.Entity<Orders>().ToTable("Orders");
        }
    }
}

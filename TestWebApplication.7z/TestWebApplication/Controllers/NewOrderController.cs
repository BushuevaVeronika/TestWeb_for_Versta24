﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TestWebApplication.Models;
using Дизайн_интерьера.Domain;

namespace TestWebApplication.Controllers
{
   
    public class NewOrderController : Controller
    {
        private readonly DBcontext _dbContext;

        public NewOrderController(DBcontext dbContext)
        {
            _dbContext = dbContext;
        }
        public IActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(Orders order)
        {
            if (ModelState.IsValid)
            {
                _dbContext.Orders.Add(order);
                _dbContext.SaveChanges();
                TempData["SuccessMessage"] = "Заказ успешно оформлен";
                return RedirectToAction("Index");
            }

            return RedirectToAction("Index");
        }
    }
}
